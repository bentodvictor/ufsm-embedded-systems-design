/*
		Giuliano Bohn Benedeti Becker
		Keli Tauana Ruppenthal
		Victor Dallagnol Bento
*/

void led_config(uint8_t led_num, uint8_t pin);	// Configura Pino
void led_on(uint8_t led_num); // ligar
void led_off(uint8_t led_num); // desligar
void led_toggle(uint8_t led_num); // alternar