/*
 * FSM com switch
 *
 */

#include <stdlib.h>
#include <stdio.h>

#include "fsm_switch_case.h"

int main(void)
{
    while (1)
    {
		fsm_switch_case_teste();
	}
}

